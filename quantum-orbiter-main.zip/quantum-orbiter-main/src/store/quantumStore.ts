import { create } from 'zustand';

export interface BlochState {
  x: number;
  y: number;
  z: number;
  purity: number;
}

export interface QubitState {
  id: number;
  bloch: BlochState;
  rho: [[number, number], [number, number]]; // 2x2 density matrix
  label: string;
}

export interface SimulationState {
  status: 'idle' | 'running' | 'paused' | 'completed' | 'error';
  progress: number;
  pipeline: 'exact' | 'estimated';
  shots: number;
}

export interface QuantumState {
  // Core state
  qubits: QubitState[];
  simulation: SimulationState;
  
  // UI state
  selectedQubit: number | null;
  endianness: 'little' | 'big';
  compactMode: boolean;
  
  // Circuit input
  qasmCode: string;
  presetCircuit: string;
  
  // Actions
  setQubits: (qubits: QubitState[]) => void;
  updateQubit: (id: number, updates: Partial<QubitState>) => void;
  setSelectedQubit: (id: number | null) => void;
  setSimulationStatus: (status: SimulationState['status']) => void;
  setQasmCode: (code: string) => void;
  setPresetCircuit: (preset: string) => void;
  toggleEndianness: () => void;
  toggleCompactMode: () => void;
  resetSimulation: () => void;
}

export const useQuantumStore = create<QuantumState>((set, get) => ({
  // Initial state
  qubits: generateInitialQubits(3),
  simulation: {
    status: 'idle',
    progress: 0,
    pipeline: 'exact',
    shots: 1024,
  },
  selectedQubit: null,
  endianness: 'little',
  compactMode: false,
  qasmCode: `OPENQASM 2.0;
include "qelib1.inc";

qreg q[3];

// Create Bell state
h q[0];
cx q[0], q[1];`,
  presetCircuit: 'bell',
  
  // Actions
  setQubits: (qubits) => set({ qubits }),
  
  updateQubit: (id, updates) => set((state) => ({
    qubits: state.qubits.map(qubit => 
      qubit.id === id ? { ...qubit, ...updates } : qubit
    )
  })),
  
  setSelectedQubit: (id) => set({ selectedQubit: id }),
  
  setSimulationStatus: (status) => set((state) => ({
    simulation: { ...state.simulation, status }
  })),
  
  setQasmCode: (code) => set({ qasmCode: code }),
  
  setPresetCircuit: (preset) => set({ presetCircuit: preset }),
  
  toggleEndianness: () => set((state) => ({
    endianness: state.endianness === 'little' ? 'big' : 'little'
  })),
  
  toggleCompactMode: () => set((state) => ({
    compactMode: !state.compactMode
  })),
  
  resetSimulation: () => set((state) => ({
    simulation: { ...state.simulation, status: 'idle', progress: 0 },
    qubits: generateInitialQubits(state.qubits.length)
  })),
}));

function generateInitialQubits(count: number): QubitState[] {
  return Array.from({ length: count }, (_, i) => ({
    id: i,
    bloch: { x: 0, y: 0, z: 1, purity: 1 }, // |0⟩ state
    rho: [[1, 0], [0, 0]], // |0⟩⟨0|
    label: `Q${i}`,
  }));
}

// Preset circuits for quick demos
export const PRESET_CIRCUITS = {
  bell: {
    name: 'Bell State',
    qasm: `OPENQASM 2.0;
include "qelib1.inc";
qreg q[2];
h q[0];
cx q[0], q[1];`,
    description: 'Create an entangled Bell state between two qubits',
  },
  ghz: {
    name: 'GHZ State',
    qasm: `OPENQASM 2.0;
include "qelib1.inc";
qreg q[3];
h q[0];
cx q[0], q[1];
cx q[1], q[2];`,
    description: 'Three-qubit GHZ entangled state',
  },
  superposition: {
    name: 'Superposition',
    qasm: `OPENQASM 2.0;
include "qelib1.inc";
qreg q[1];
h q[0];`,
    description: 'Single qubit in superposition state',
  },
  random: {
    name: 'Random State',
    qasm: `OPENQASM 2.0;
include "qelib1.inc";
qreg q[2];
ry(1.57) q[0];
rx(0.78) q[1];`,
    description: 'Random quantum state for demonstration',
  },
};